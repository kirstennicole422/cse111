# print(f"{current_date_and_time:%Y-%m-%d}")
for year, month, day date format
    
to pull date from computer
from datetime import datetime
day_and_time = datetime.now()

for day of week (starting with monday = 0)
day_and_time.


# # To call a built-in function, write code that follows this template:
# variable_name = function_name(arg1, arg2, … argN)
# # To call a function from a module, import the module and write code that follows this template:
# import module_name
# variable_name = module_name.function_name(arg1, arg2, … argN)
# # To call a method, write code that follows this template:
# variable_name = object_name.method_name(arg1, arg2, … argN)